package inheritance;

//import interfaces.one;
//import interfaces.two;
//
//public abstract class InterfaceDemo implements one, two{
//	
//	
//	public static void main(String[] args) {
//		
//		one.add(1,2);
//		two.sub(12, 2);
//	}
/**
 * Here we can  not do the multiple inheritance in class level but
 * we can do multiple inheritance in interface level
 * in interface we can mention only methods 
 * for implementation we need to specify the static and default keywords
 * every method in interface is a abstract class we no need to specify it
 * 	ABSTRACTION 
 */
	


//}
