package inheritance;

public class Super extends SuperSuper {
	public void divsion() {
		System.out.println("In Super Division");
//		SuperSuper su = new SuperSuper();
		
		//su.add();
	}
	
	
}
