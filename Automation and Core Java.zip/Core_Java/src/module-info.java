module Core_Java {
}