package arrays;

import java.util.Arrays;

public class ArrayRotationBynum {

	public static void main(String[] args) {
		int[] a = { 12, 76, 99, 98, 896, 768, 976 };
		int d = 3;
		int[] b = new int[d];
		int[] c = new int[a.length - d];
		for (int i = 0; i < b.length; i++) {
			b[i] = a[i];
		}
		for (int i = d; i < a.length; i++) {
			for (int j = 0; j < c.length; j++)
				c[j] = a[i];
		}

		System.out.println(Arrays.toString(b) + Arrays.toString(c));
//		Vector<Integer> f = new Vector();

//		System.out.println(f);

	}

}
