package arrays;

public class Names {
	public static void main(String[] args) {
		String[] x = { "Sujith", "Jan" };
		String[][] y = { { "Jashu", "age" }, { "Vishu", "age" } };
		String[][] z = new String[2][3];
		System.out.println(z[1].length);
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(y[0][0]);
	}

}
