package Collections;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<String> a = new ArrayList<>();
		a.add(null);
		a.add("Jashu");
		System.out.println(a);
		a.add("");
		a.set(2, "Jhon");
		System.out.println(a);
		

	}

}
