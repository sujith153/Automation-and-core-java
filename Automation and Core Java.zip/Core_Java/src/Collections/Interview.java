package Collections;

import java.util.HashSet;
import java.util.Set;

public class Interview {
	public static void main(String[] args) {
		String name = "Sujith Vardhan Reddy";
	    String course = new String("EEE");
	    System.out.println(course.contains(name));
	    char[] chars = name.toCharArray();
	    Set<Character> word = new HashSet<>();
	    for (int i = 0; i < chars.length; i++) {
	    	word.add(chars[i]);
		}
	    System.out.print(word);
	}
	
}
