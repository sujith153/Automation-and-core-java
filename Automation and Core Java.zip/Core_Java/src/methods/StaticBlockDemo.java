package methods;

public class StaticBlockDemo {
	static {
		Old one = new Old();
		one.printIntegerArray(one.numbers(10));
	}
	public static void main(String[] args) {
		
		
	}
	
}
