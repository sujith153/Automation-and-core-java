package singletonPattern;

public class MainClass {

	public static void main(String[] args) {
		Single s1 = Single.getInstance();
		s1.display();

	}

}
