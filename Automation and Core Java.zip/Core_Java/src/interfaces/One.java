package interfaces;

public interface One {
	static void add(int a , int b) {
		System.out.println(a+b);
	}
	void mul();
	void sub(int a, int b);

}
