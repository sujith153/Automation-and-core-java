package firstprogram;

import java.util.Properties;

public class NamingConventionDemo {
	
	Properties p = new Properties();
	
	int x = 10;
	long y = 1234567890123456L;
	float z = 10.67F;
	double d = 189.9876543219876543;
	
	char ch = 'D';
	
	
	
	String firstName = "Chennupalli";
	
	
	

}
