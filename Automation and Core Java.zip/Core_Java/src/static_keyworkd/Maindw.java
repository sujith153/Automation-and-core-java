package static_keyworkd;

public class Maindw extends StaticDemo{
	public static void main(String[] args) {
		System.out.println(z);
	}

}
