package operators;

public class PracOp {
	void lndv() {
		System.out.println();
		System.out.println();
		System.out.println();
	}
	public static void main(String[] args) {
//		int a = 10, b = 20, c = 30;
//		int d = a++; 
	
//		System.out.println(d);
//		System.out.println(a<b);
//		System.out.println(a>b);
//		System.out.println(a<=b);
//		System.out.println(a>=b);
//		System.out.println(a!=b);
//		a =10....a++...b =a\
		
		//Logical operators
		//(&&,||,!)
//		System.out.println(a<b && b<c);
//		System.out.println(a<b && c<b && d<a);
//		System.out.println(a<b || b<c);
//		boolean aa = false;
//		boolean bb = false;
//		
//		System.out.println(!aa);
//		System.out.println();
		
//		int f = 27;// 1 1 0 1 1
//		int g = 78;
		//       1 1 0 1 1
		//   1 0 0 1 1 1 0
		//&  0 0 0 1 0 1 0
		//|  1 0 1 1 1 1 1
//		System.out.println(g&f);
//		System.out.println(g|f);
//		char ff = 'a';
//		int gg = ff;
//		System.out.println(gg);
		System.out.println();

	}

}
