package operators;

public class Examples {
	
	static String fv = "APPles";
	static StringBuilder b = new StringBuilder("Apples");


}

