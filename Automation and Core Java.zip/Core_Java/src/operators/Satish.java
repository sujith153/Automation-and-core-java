package operators;

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Queue;

public class Satish {
	public static void main(String[] args) {
	Queue<Integer> f = new PriorityQueue<>();
	f.add(32);
	f.add(3);
	f.add(23);
	f.add(34);
	f.add(1);
	f.add(1);
	
	int[] d = new int[f.size()];
	
	for (int i = 0; i < d.length; i++) {
		d[i] = f.poll();
	}
	System.out.println(Arrays.toString(d));
	}

	
}
